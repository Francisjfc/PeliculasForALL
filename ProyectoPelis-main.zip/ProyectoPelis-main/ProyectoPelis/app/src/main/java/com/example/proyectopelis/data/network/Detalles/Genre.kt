package com.example.proyectopelis.data.network.Detalles

data class Genre(
    val id: Int,
    val name: String
)