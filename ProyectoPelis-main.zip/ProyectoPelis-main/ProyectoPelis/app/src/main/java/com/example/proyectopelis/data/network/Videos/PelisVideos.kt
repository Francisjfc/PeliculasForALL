package com.example.proyectopelis.data.network.Videos

data class PelisVideos(
    val id: Int,
    val results: List<Result>
)